﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDbApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // static type (left) = dynamic type (right)
            DbApp app = new DbApp();
        }
    }
}
